# Entry point for the application.
from __init__ import app    # For application discovery by the 'flask' command.
import views as views  # For import side-effects of setting up routes.